package com.elife.event.dao.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.elife.event.dao.entities.User;

public interface UserRepository  extends JpaRepository<User,Long>{
    Optional<User> findByEmail(String email);

}