package com.elife.event.dto;

import com.elife.event.dao.entities.Event;
import com.elife.event.dao.entities.Reservation;
import com.elife.event.dao.entities.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ReservationDto {
    private Long id;
    private User user;
    private Long eventId;
    public static ReservationDto fromEntity(Reservation reservation) {
        if (reservation == null) {
            return null;
        }
        return new ReservationDto(
            reservation.getId(),
            reservation.getUser(),
            reservation.getEvent() != null ? reservation.getEvent().getId() : null
        );
    }

    public static Reservation toEntity(ReservationDto dto, Event event) {
        if (dto == null) {
            return null;
        }
        Reservation reservation = new Reservation();
        reservation.setId(dto.getId());
        reservation.setUser(dto.getUser());
        reservation.setEvent(event);
        return reservation;
    }
}
