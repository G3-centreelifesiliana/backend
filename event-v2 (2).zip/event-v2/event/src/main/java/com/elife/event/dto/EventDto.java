package com.elife.event.dto;

import java.util.stream.Collectors;

import com.elife.event.dao.entities.Category;
import com.elife.event.dao.entities.Event;
import com.elife.event.dao.entities.Reservation;
import java.util.Date;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class EventDto {
     private Long id;

    private String name;
    private Date date;
    private String description;
    private String location;
    private Long categoryId;
    private Set<Long> reservationIds;

    public static EventDto toDTO(Event event) {
        if (event == null) {
            return null;
        }
        return new EventDto(
                event.getId(),
                event.getName(),
                event.getDate(),
                event.getDescription(),
                event.getLocation(),
                event.getCategory().getId(),
                event.getReservations().stream()
                        .map(Reservation::getId)
                        .collect(Collectors.toSet())
        );
    }

    

    public static Event toEntity(EventDto dto, Category category, Set<Reservation> reservations) {
        if (dto == null) {
            return null;
        }
        Event event = new Event();
        event.setId(dto.getId());
        event.setName(dto.getName());
        event.setDate(dto.getDate());
        event.setDescription(dto.getDescription());
        event.setLocation(dto.getLocation());
        event.setCategory(category);
        event.setReservations(reservations);
        return event;
    }
}