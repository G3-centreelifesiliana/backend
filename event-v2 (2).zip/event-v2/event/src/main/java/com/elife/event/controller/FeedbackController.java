package com.elife.event.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.event.business.services.FeedbackService;
import com.elife.event.dto.FeedbackDto;

@RestController
@RequestMapping("/feedbacks")
@PreAuthorize("hasAnyRole('ADMIN','USER')")
public class FeedbackController {
    
     
    private final FeedbackService feedbackService;
     public FeedbackController(FeedbackService feedbackService){
        this.feedbackService=feedbackService;
     }
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")

    public ResponseEntity<FeedbackDto> getFeedbackById(@PathVariable Long id) {
        FeedbackDto feedbackDto = feedbackService.getFeedbackById(id);
        if (feedbackDto != null) {
            return ResponseEntity.ok(feedbackDto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('ADMIN', 'USER') and hasAuthority('READ_PRIVILEGE')")

    public ResponseEntity<List<FeedbackDto>> getAllFeedbacks() {
        List<FeedbackDto> feedbacks = feedbackService.getAllFeedbacks();
        if (!feedbacks.isEmpty()) {
            return ResponseEntity.ok(feedbacks);
        } else {
            return ResponseEntity.noContent().build();
        }
    }

    @PostMapping("/create")
    @PreAuthorize("hasAuthority('WRITE_PRIVILEGE') and hasRole('USER')")

    public ResponseEntity<FeedbackDto> createFeedback(@RequestBody FeedbackDto feedbackDto) {
        FeedbackDto createdFeedback = feedbackService.createFeedback(feedbackDto);
        return ResponseEntity.ok(createdFeedback);
    }

    @PutMapping("/update/{id}")
    @PreAuthorize("hasAuthority('UPDATE_PRIVILEGE') and hasRole('USER')")

    public ResponseEntity<FeedbackDto> updateFeedback(@PathVariable Long id, @RequestBody FeedbackDto feedbackDto) {
        FeedbackDto updatedFeedback = feedbackService.updateFeedback(id, feedbackDto);
        if (updatedFeedback != null) {
            return ResponseEntity.ok(updatedFeedback);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping("/delete/{id}")
    @PreAuthorize("hasAuthority('DELETE_PRIVILEGE') and hasRole('ADMIN')")

    public ResponseEntity<Void> deleteFeedback(@PathVariable Long id) {
        // Supprimer le feedback avec l'ID spécifié
        feedbackService.deleteFeedback(id);

        // Retourner une ResponseEntity avec un statut No Content
        return ResponseEntity.noContent().build();
    }
    }

