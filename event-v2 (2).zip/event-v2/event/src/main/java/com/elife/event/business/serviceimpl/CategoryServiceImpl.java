package com.elife.event.business.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.elife.event.business.services.CategoryService;
import com.elife.event.dao.entities.Category;
import com.elife.event.dao.repositories.CategoryRepository;
import com.elife.event.dto.CategoryDto;

@Service
public class CategoryServiceImpl implements CategoryService{

    private final CategoryRepository categoryRepository;
    public  CategoryServiceImpl (CategoryRepository categoryRepository){
    this.categoryRepository=categoryRepository;
}
@Override
public CategoryDto getCategoryById(Long id) {
    return categoryRepository.findById(id)
            .map(CategoryDto::fromEntity)
            .orElse(null);
}



@Override
public CategoryDto createCategory(CategoryDto categoryDto) {
    Category category = CategoryDto.toEntity(categoryDto); // Convert DTO to Entity
    Category savedCategory = categoryRepository.save(category);
    return CategoryDto.fromEntity(savedCategory); // Convert Entity back to DTO
}

@Override
public CategoryDto updateCategory(Long id, CategoryDto categoryDto) {
    Category categoryToUpdate = categoryRepository.findById(id).orElse(null);
    if (categoryToUpdate != null) {
        categoryToUpdate.setName(categoryDto.getName());
        Category updatedCategory = categoryRepository.save(categoryToUpdate);
        return CategoryDto.fromEntity(updatedCategory);
    }
    return null;
}

@Override
public void deleteCategory(Long id) {
    categoryRepository.deleteById(id);
}
@Override
public List<CategoryDto> getAllcategories() {
    return categoryRepository.findAll().stream()
            .map(CategoryDto::fromEntity)
            .collect(Collectors.toList());
}



    
}