package com.elife.event.business.services;

import java.util.List;

import com.elife.event.dto.ReservationDto;

public interface ReservationService {
    ReservationDto createReservation(ReservationDto reservationDto);
    ReservationDto updateReservation(Long id, ReservationDto reservationDto);
    void deleteReservation(Long id);
    ReservationDto getReservationById(Long id);
    List<ReservationDto> getAllReservations();
}    
