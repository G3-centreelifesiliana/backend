package com.elife.event.dao.entities.enums;

public enum Privilege {
    READ_PRIVILEGE,
    WRITE_PRIVILEGE,
    DELETE_PRIVILEGE,
    UPDATE_PRIVILEGE;
}