package com.elife.event.dao.entities;

import java.util.Set;

import com.elife.event.dao.entities.enums.CategoryType;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;
@Data
@Entity
@Table
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long id;
    private String name;
    
    @Enumerated(EnumType.STRING)
    private CategoryType type;
 @OneToMany(mappedBy = "category")
    private Set<Event> events;
    
}