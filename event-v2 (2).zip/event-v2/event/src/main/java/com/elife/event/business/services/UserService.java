package com.elife.event.business.services;
import java.util.List;

import com.elife.event.dto.UserDto;

public interface UserService {

    UserDto getUserByUsername(String username);

    UserDto createUser(UserDto user);


    void deleteUser(Long id);

    List<UserDto> getAllUsers();
}