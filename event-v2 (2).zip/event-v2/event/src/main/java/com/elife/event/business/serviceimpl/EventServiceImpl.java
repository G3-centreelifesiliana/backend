package com.elife.event.business.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.elife.event.business.services.EventService;
import com.elife.event.dao.entities.Category;
import com.elife.event.dao.entities.Event;
import com.elife.event.dao.entities.Reservation;
import com.elife.event.dao.repositories.CategoryRepository;
import com.elife.event.dao.repositories.EventRepository;
import com.elife.event.dao.repositories.ReservationRepository;
import com.elife.event.dto.EventDto;

@Service
public class EventServiceImpl implements EventService{
      private final EventRepository eventRepository;
          private final CategoryRepository categoryRepository;
             private final ReservationRepository reservationRepository;

    public EventServiceImpl(EventRepository eventRepository, CategoryRepository categoryRepository,ReservationRepository reservationRepository) {
        this.eventRepository = eventRepository;
        this.categoryRepository=categoryRepository;
        this.reservationRepository=reservationRepository;
    }
    @Override
    public EventDto createEvent(EventDto eventDto) {
        Category category = categoryRepository.findById(eventDto.getCategoryId()).orElse(null);
        Set<Reservation> reservations = eventDto.getReservationIds().stream()
                .map(reservationRepository::findById)
                .map(optional -> optional.orElse(null))
                .collect(Collectors.toSet());

        Event event = EventDto.toEntity(eventDto, category, reservations);
        return EventDto.toDTO(eventRepository.save(event));
    }

    @Override
    public EventDto updateEvent(Long id, EventDto eventDto) {
        Category category = categoryRepository.findById(eventDto.getCategoryId()).orElse(null);
        Set<Reservation> reservations = eventDto.getReservationIds().stream()
                .map(reservationRepository::findById)
                .map(optional -> optional.orElse(null))
                .collect(Collectors.toSet());

        Event event = eventRepository.findById(id).orElse(null);
        if (event != null) {
            event.setName(eventDto.getName());
            event.setDate(eventDto.getDate());
            event.setDescription(eventDto.getDescription());
            event.setLocation(eventDto.getLocation());
            event.setCategory(category);
            event.setReservations(reservations);
            return EventDto.toDTO(eventRepository.save(event));
        }
        return null;
    }

    @Override
    public void deleteEvent(Long id) {
        eventRepository.deleteById(id);
    }

    @Override
    public EventDto getEventById(Long id) {
        return eventRepository.findById(id).map(EventDto::toDTO).orElse(null);
    }

    @Override
    public List<EventDto> getAllEvents() {
        return eventRepository.findAll().stream()
                .map(EventDto::toDTO)
                .collect(Collectors.toList());
    }
    @Override
    public List<EventDto> getEventsByCategory(Long categoryId) {
        return eventRepository.findByCategoryId(categoryId).stream()
                .map(EventDto::toDTO)
                .collect(Collectors.toList());
    }
    
}