package com.elife.event.dto;

import java.util.Set;

import com.elife.event.dao.entities.Feedback;
import com.elife.event.dao.entities.Reservation;
import com.elife.event.dao.entities.User;
import com.elife.event.dao.entities.enums.Role;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UserDto {

     private Long id;
    private String username;
    private String password;
    private String email;
    private Role role;

    
    
    private Set<Reservation> reservation;
    
    private Set<Feedback> feedbacks;

    public static UserDto toDTO(User user) {
        if (user == null) {
            return null;
        }
        return UserDto.builder()
                .username(user.getUsername())
                 .password(user.getPassword())
                 .email(user.getEmail())
                 .role(user.getRole())
                .build();
    }

    public static User toEntity(UserDto dto) {
        if (dto == null) {
            return null;
        }
        User user = new User();
       user.setUsername(dto.getUsername());
       user.setPassword(dto.getPassword());
       user.setEmail(dto.getEmail());
       user.setRole(dto.getRole());
        return user;
    }
}