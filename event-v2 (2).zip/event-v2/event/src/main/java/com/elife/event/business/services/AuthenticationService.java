package com.elife.event.business.services;

import org.springframework.security.core.Authentication;

import com.elife.event.dao.entities.User;
import com.elife.event.dto.AuthenticationUserDTO;
import com.elife.event.exception.DuplicateUserException;
public interface AuthenticationService {
   
    User register(User user) throws DuplicateUserException;
   AuthenticationUserDTO login(Authentication authentication);
}