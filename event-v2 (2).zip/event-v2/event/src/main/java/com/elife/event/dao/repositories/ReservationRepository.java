package com.elife.event.dao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.elife.event.dao.entities.Reservation;

public interface ReservationRepository extends JpaRepository<Reservation,Long>{
    
}