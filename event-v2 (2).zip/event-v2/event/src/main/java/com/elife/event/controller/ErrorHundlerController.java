package com.elife.event.controller;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@Controller
public class ErrorHundlerController {
      @ExceptionHandler(Exception.class)
   // @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handelExeption(Exception e, Model model){
        model.addAttribute("ErrorMsg", e.getMessage());
         return "Errors";
    }
}