package com.elife.event.business.services;

import java.util.List;

import com.elife.event.dao.entities.Event;
import com.elife.event.dto.EventDto;

public interface EventService {
    EventDto createEvent(EventDto eventDto);
    EventDto updateEvent(Long id, EventDto eventDto);
    void deleteEvent(Long id);
    EventDto getEventById(Long id);
    List<EventDto> getAllEvents();
    List<EventDto> getEventsByCategory(Long categoryId);
}