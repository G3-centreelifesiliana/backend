package com.elife.event.business.services;

import java.util.List;

import com.elife.event.dao.entities.Category;
import com.elife.event.dto.CategoryDto;

public interface CategoryService {
    
    CategoryDto getCategoryById(Long id);
    CategoryDto createCategory(CategoryDto categorydto);
    CategoryDto updateCategory(Long id, CategoryDto category);
    void deleteCategory(Long id);
    List<CategoryDto> getAllcategories();
}