package com.elife.event.dto;

import com.elife.event.dao.entities.Event;
import com.elife.event.dao.entities.Feedback;
import com.elife.event.dao.entities.Reservation;
import com.elife.event.dao.entities.User;

import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FeedbackDto {
    
    private String name;
    private String feedback;
    private EventDto event;
    private User user;

    public static FeedbackDto toDTO(Feedback feedback) {
        if (feedback == null) {
            return null;
        }
        return FeedbackDto.builder()
                .name(feedback.getName())
                .feedback(feedback.getFeedback())
                .event(EventDto.toDTO(feedback.getEvent()))
                .user(feedback.getUser())
                .build();
    }

    public static Feedback toEntity(FeedbackDto dto) {
        if (dto == null) {
            return null;
        }
        Feedback feedback = new Feedback();
        feedback.setName(dto.getName());
        feedback.setFeedback(dto.getFeedback());
        feedback.setUser(dto.getUser());
        feedback.setEvent(EventDto.toEntity(dto.getEvent(),null,null));
        return feedback;
    }
}
