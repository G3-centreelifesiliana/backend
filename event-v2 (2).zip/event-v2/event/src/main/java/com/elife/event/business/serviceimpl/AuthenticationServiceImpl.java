package com.elife.event.business.serviceimpl;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.elife.event.business.services.AuthenticationService;
import com.elife.event.dao.entities.User;
import com.elife.event.dao.repositories.UserRepository;
import com.elife.event.dto.AuthenticationUserDTO;
import com.elife.event.exception.DuplicateUserException;
@Service
public class AuthenticationServiceImpl implements AuthenticationService {
    private final UserRepository userRepository;

    public AuthenticationServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User register(User user) throws DuplicateUserException {
        if (user == null) {
            return null;
        }
        try {
            return userRepository.save(user);
        } catch (DataIntegrityViolationException e) {
            throw new DuplicateUserException("User already exists");
        }
    }

    @Override
    public AuthenticationUserDTO login(Authentication authentication) {
        User user = (User) authentication.getPrincipal();
        return AuthenticationUserDTO.toAuthenticationUserDTO(user);
    }
}