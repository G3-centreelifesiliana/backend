package com.elife.event.business.services;

import java.util.List;

import com.elife.event.dao.entities.Feedback;
import com.elife.event.dto.FeedbackDto;

public interface FeedbackService {
    FeedbackDto createFeedback(FeedbackDto feedbackDto);
    FeedbackDto updateFeedback(Long id, FeedbackDto feedbackDto);
    void deleteFeedback(Long id);
    FeedbackDto getFeedbackById(Long id);
    List<FeedbackDto> getAllFeedbacks();
}