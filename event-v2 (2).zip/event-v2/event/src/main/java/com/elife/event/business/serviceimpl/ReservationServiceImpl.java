package com.elife.event.business.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.elife.event.business.services.ReservationService;
import com.elife.event.dao.entities.Event;
import com.elife.event.dao.entities.Reservation;
import com.elife.event.dao.repositories.EventRepository;
import com.elife.event.dao.repositories.ReservationRepository;
import com.elife.event.dto.ReservationDto;

@Service
public class ReservationServiceImpl implements ReservationService {
       private final ReservationRepository reservationRepository;
       private final EventRepository eventrepository;
    public ReservationServiceImpl(ReservationRepository reservationRepository,EventRepository eventRepository) {
        this.reservationRepository = reservationRepository;
        this.eventrepository=eventRepository;

    }
 @Override
    public ReservationDto createReservation(ReservationDto reservationDto) {
        Event event = eventrepository.findById(reservationDto.getEventId()).orElse(null);
        Reservation reservation = ReservationDto.toEntity(reservationDto, event);
        return ReservationDto.fromEntity(reservationRepository.save(reservation));
    }

    @Override
    public ReservationDto updateReservation(Long id, ReservationDto reservationDto) {
        Event event = eventrepository.findById(reservationDto.getEventId()).orElse(null);

        Reservation reservation = reservationRepository.findById(id).orElse(null);
        if (reservation != null) {
            reservation.setId(reservationDto.getId());
            reservation.setEvent(event);
            return ReservationDto.fromEntity(reservationRepository.save(reservation));
        }
        return null;
    }

    @Override
    public void deleteReservation(Long id) {
        reservationRepository.deleteById(id);
    }

    @Override
    public ReservationDto getReservationById(Long id) {
        return reservationRepository.findById(id).map(ReservationDto::fromEntity).orElse(null);
    }

    @Override
    public List<ReservationDto> getAllReservations() {
        return reservationRepository.findAll().stream()
                .map(ReservationDto::fromEntity)
                .collect(Collectors.toList());
    }
    

    

    


}