package com.elife.event.dao.entities.enums;

public enum CategoryType {
    SPECTACLE,
        SPORT,
        FILM
}