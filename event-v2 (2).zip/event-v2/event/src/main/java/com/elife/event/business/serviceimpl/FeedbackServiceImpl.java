package com.elife.event.business.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.elife.event.business.services.FeedbackService;
import com.elife.event.dao.entities.Event;
import com.elife.event.dao.entities.Feedback;
import com.elife.event.dao.entities.User;
import com.elife.event.dao.repositories.EventRepository;
import com.elife.event.dao.repositories.FeedbackRepository;
import com.elife.event.dao.repositories.UserRepository;
import com.elife.event.dto.FeedbackDto;

@Service
public class FeedbackServiceImpl implements FeedbackService{
    

    private final FeedbackRepository feedbackRepository;
    private final EventRepository eventRepository;
    private final UserRepository userRepository;
public FeedbackServiceImpl(FeedbackRepository feedbackRepository,EventRepository eventRepository, UserRepository userRepository){
    this.feedbackRepository=feedbackRepository;
    this.eventRepository=eventRepository;
    this.userRepository=userRepository;
}
@Override
public FeedbackDto createFeedback(FeedbackDto feedbackDto) {
    Optional<Event> event = eventRepository.findById(feedbackDto.getEvent().getId());
    Optional<User> user = userRepository.findById(feedbackDto.getUser().getId());
    
    if (event.isPresent() && user.isPresent()) {
        Feedback feedback = FeedbackDto.toEntity(feedbackDto);
        feedback.setEvent(event.get());
        feedback.setUser(user.get());
        return FeedbackDto.toDTO(feedbackRepository.save(feedback));
    } else {
        // Handle case where event or user is not found
        return null;
    }
}

@Override
public FeedbackDto updateFeedback(Long id, FeedbackDto feedbackDto) {
    Optional<Event> eventOptional = eventRepository.findById(feedbackDto.getEvent().getId());
    Optional<User> userOptional = userRepository.findById(feedbackDto.getUser().getId());

    if (eventOptional.isPresent() && userOptional.isPresent()) {
        Optional<Feedback> feedbackOptional = feedbackRepository.findById(id);
        if (feedbackOptional.isPresent()) {
            Feedback feedback = feedbackOptional.get();
            feedback.setName(feedbackDto.getName());
            feedback.setFeedback(feedbackDto.getFeedback());
            feedback.setEvent(eventOptional.get());
            feedback.setUser(userOptional.get());
            return FeedbackDto.toDTO(feedbackRepository.save(feedback));
        }
    }
    return null;
}

@Override
public void deleteFeedback(Long id) {
    feedbackRepository.deleteById(id);
}

@Override
public FeedbackDto getFeedbackById(Long id) {
    return feedbackRepository.findById(id).map(FeedbackDto::toDTO).orElse(null);
}

@Override
public List<FeedbackDto> getAllFeedbacks() {
    return feedbackRepository.findAll().stream()
            .map(FeedbackDto::toDTO)
            .collect(Collectors.toList());
}

}