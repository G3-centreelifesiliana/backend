package com.elife.event.business.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.elife.event.business.services.UserService;
import com.elife.event.dao.entities.User;
import com.elife.event.dao.repositories.UserRepository;
import com.elife.event.dto.UserDto;

import jakarta.persistence.EntityNotFoundException;
@Service
public class UserServiceImpl implements UserService{
    private UserRepository userRepository ;

    @Autowired
    public UserServiceImpl(UserRepository utilisateurRepository) {
      this.userRepository = utilisateurRepository;
      
    }

    @Override
    public UserDto createUser(UserDto dto) {
          User user = UserDto.toEntity(dto); // Convert DTO to Entity
   User saveduser = userRepository.save(user);
    return UserDto.toDTO(saveduser); // Convert Entity back to DTO
    
    }
    @Override
    public void deleteUser(Long id) {
            if (id == null) {
                throw new IllegalArgumentException("Utilisateur ID is null");

            }
            userRepository.deleteById(id);
          }
    

    @Override
    public List<UserDto> getAllUsers() {
          return userRepository.findAll().stream()
          .map(UserDto::toDTO)
          .collect(Collectors.toList());
    }

    

    @Override
    public UserDto getUserByUsername(String username) {
        return userRepository.findByEmail(username)
                .map(UserDto::toDTO) // Assuming fromEntity is a static method in UserDto to convert User entity to UserDto
                .orElseThrow(() -> new EntityNotFoundException(
                        "Aucun utilisateur avec l'email = " + username + " n'a été trouvé dans la BDD"));
    }

    

}
    
