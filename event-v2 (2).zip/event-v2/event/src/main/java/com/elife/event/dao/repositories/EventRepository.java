package com.elife.event.dao.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.elife.event.dao.entities.Event;

public interface EventRepository extends JpaRepository<Event,Long> {
    List<Event> findByCategoryId(Long categoryId);

}