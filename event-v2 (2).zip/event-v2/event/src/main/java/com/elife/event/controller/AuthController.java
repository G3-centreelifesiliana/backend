package com.elife.event.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.event.business.services.AuthenticationService;
import com.elife.event.business.services.JwtService;
import com.elife.event.dao.entities.User;
import com.elife.event.dto.AuthenticationUserDTO;
import com.elife.event.dto.RegisterUserDTO;
import com.elife.event.exception.DuplicateUserException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationService authenticationService;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthController(AuthenticationService authenticationService,
                           PasswordEncoder passwordEncoder,
                           JwtService jwtService) {
        this.authenticationService = authenticationService;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    @PostMapping("/signin")
    public ResponseEntity<AuthenticationUserDTO> auth(Authentication authentication) {
        AuthenticationUserDTO authenticationUserDTO = this.authenticationService.login(authentication);
        ResponseCookie jwtCookie = jwtService.generateJwtCookie(jwtService.generateToken(authentication));
        return ResponseEntity.ok()
                .header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
                .body(authenticationUserDTO);
    }

    @PostMapping("/signup")
    public ResponseEntity<RegisterUserDTO> register(@Valid @RequestBody RegisterUserDTO registerUserDTO) throws DuplicateUserException {
        User user = authenticationService
                .register(RegisterUserDTO.fromRegisterUserDTO(registerUserDTO, passwordEncoder));
        return ResponseEntity.ok()
                .body(RegisterUserDTO.toRegisterUserDTO(user));
    }

    @PostMapping("/signout")
    public ResponseEntity<Void> logout(HttpServletRequest request) {
        ResponseCookie jwtCookie = jwtService.getCleanJwtCookie();
        return ResponseEntity.ok()
                .header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
                .build();
    }
}