package com.elife.event.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.elife.event.business.services.UserService;
import com.elife.event.dto.UserDto;

@RestController
@RequestMapping("/user")
public class UserController {
    
     final UserService userService;

  public UserController(UserService userService) {
    this.userService = userService;
  }

    @PostMapping("/create")
  public UserDto createUser(@RequestBody UserDto dto) {
    return userService.createUser(dto);
  }

 



  @GetMapping("/{username}")
  public UserDto getUserByUsername(@PathVariable("username") String username) {
    return userService.getUserByUsername(username);
  }

  @GetMapping("/all")
  
  public List<UserDto> getAllUsers() {
    return userService.getAllUsers();
  }

    @DeleteMapping("/delete/{id}")
  public void deleteUser(@PathVariable("id")Long id) {
    userService.deleteUser(id);
  }}